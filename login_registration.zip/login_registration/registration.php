<?php
   
    $conn = mysqli_connect("localhost","root","1234","koach_task");
   
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
else
{
echo "success";
}

     $name = $_POST['name'];
     $email = $_POST['email'];
     $pass = $_POST['pass'];
     $sql = "INSERT INTO registration (name,email,pass)
     VALUES ('$name','$email','$pass')";
 $sql1 = "INSERT INTO login (email,pass)
     VALUES ('$email','$pass')";
     if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
if (mysqli_query($conn, $sql1)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql1 . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);

?>